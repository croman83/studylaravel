<template>
    <div class="footer-content">

    </div>
</template>
<script>
    export default {

    }
</script>