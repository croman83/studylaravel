<template>
  <div class="animated fadeIn">
    <p class="text-info">Hello World</p>
  </div>
</template>

<script>
export default {
  name: 'dashboard'
}
</script>
